const images = [
  { src: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=400&q=80", alt: "Mountain landscape" },
  { src: "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=400&q=80", alt: "Forest pathway" },
  { src: "https://images.unsplash.com/photo-1526401485004-2aa7c3a9c3c5?auto=format&fit=crop&w=400&q=80", alt: "Beach sunset" },
  { src: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=400&q=80", alt: "City skyline" },
  { src: "https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=400&q=80", alt: "Snowy mountains" }
];

window.addEventListener("load", () => {
  console.log("Page loaded successfully");
  loadGallery();
});

function loadGallery() {
  const gallery = document.getElementById("gallery");
  images.forEach((imgObj) => {
    const fig = document.createElement("figure");
    fig.setAttribute("tabindex", "0");

    const img = document.createElement("img");
    img.src = imgObj.src;
    img.alt = imgObj.alt;

    const cap = document.createElement("figcaption");
    cap.textContent = imgObj.alt;

    fig.addEventListener("click", () => {
      alert(`You selected: ${imgObj.alt}`);
    });

    fig.appendChild(img);
    fig.appendChild(cap);
    gallery.appendChild(fig);
  });
}

document.addEventListener("mousemove", (e) => {
  console.log(`Mouse at X:${e.clientX}, Y:${e.clientY}`);
});

document.addEventListener("keydown", (e) => {
  console.log(`Key pressed: ${e.key}`);
});
